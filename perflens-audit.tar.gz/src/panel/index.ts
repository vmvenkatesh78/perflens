export { PerfLensPanel } from './PerfLensPanel';
